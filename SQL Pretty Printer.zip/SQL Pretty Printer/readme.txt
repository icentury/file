SQL Pretty Printer 2.8.7
Copyright 2005-2008, Gudu Software. All Rights Reserved
http://www.wangz.net/sqlpp.php
--------------------------------------------------------


Overview
--------
SQL Pretty Printer is a tool that will help you beautify your SQL code. 
Using hotkey functionality, SQL Pretty Printer can reformat SQL statements for a wide variety of 
database tools such as Microsoft Query Analyzer, SQL Server Management Studio (SSMS), 
TOAD and PL/SQL Developer, development environments such as Visual Studio 2003/2005/2008 and Eclipse, 
and popular editors such as UltraEditor and EditPlus.

In addition to beautifying SQL code, SQL Pretty Printer can translate SQL code into C#, Java, PHP, 
DELPHI and other program languages.

SQL Pretty Printer also includes command line functionality, with the ability to format single files, 
single directories and multiple directories.

SQL Pretty Printer is designed to deal with the syntax used by most popular database systems 
including Microsoft SQL Server, Oracle, IBM DB2, MySQL and Microsoft Access (Informix, Sybase, 
and PostgreSQL support is currently in development). 
Output conforms to most of the entry level SQL99 Standard.

Add-Ins for SSMS and Visual Studio 2003/2005/2008 are available.




features:

** Beautifies SQL statements utilizing highly customizable format options. 
** Formats SQL on-the-fly in popular tools and editors using hotkey functionality. 
** Minimizes to the system tray for quick access. 
** Includes a command line for batch conversion of single files, single directories or directory trees (use the command line API in your own program!) 
** Verifies SQL syntax with detailed error information. 
** Converts monochrome SQL code into colorful HTML for easy placement in blogs and forums. 
** Converts SQL to various programming languages including C#, Java, DELPHI, PHP and others. 
** Currently supports SQL syntax for Microsoft SQL Server, Oracle, IBM DB2, MySQL and Microsoft Access (Informix, Sybase, and PostgreSQL support is currently in development). 
** Add-In for SQL Server Management Studio available. 
** Add-In for Visual Studio 2003/2005/2008 available. 


Requirements
------------
Pentium class CPU or higher 
Windows 95/98/NT/2000/XP/Vista 
